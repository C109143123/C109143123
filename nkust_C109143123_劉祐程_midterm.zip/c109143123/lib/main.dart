import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'dart:async';

final player=AudioPlayer()..setReleaseMode(ReleaseMode.loop);//音樂循環

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  final tabs=[
    Center(child: screen1()),
    Center(child: screen2()),
    Center(child: screen3()),
    Center(child: screen4()),
    Center(child: screen5()),
  ];

  int _previousIndex = 0;
  int _currentindex = 0;

  @override
  Widget build(BuildContext context) {
    if (_currentindex == 0) player.play(AssetSource("z2.mp3"));
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text('C109143123Midterm'),
          backgroundColor: Colors.green,),
        body: tabs[_currentindex],
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.green,
          selectedItemColor: Colors.white,
          selectedFontSize: 20.0,
          unselectedFontSize: 15.0,
          iconSize: 30.0,
          currentIndex: _currentindex,
          items: [
            BottomNavigationBarItem(icon:_currentindex == 0?
            Image.asset("images/D1.png",width: 20,height: 20,):Icon(Icons.home),
              label: 'Home',
            ),
            BottomNavigationBarItem(icon:_currentindex == 1?
            Icon(Icons.alarm_on): Icon(Icons.alarm_off),
              label: 'Alarm',
            ),
            BottomNavigationBarItem(icon:_currentindex == 2?
            Icon(Icons.business):Icon(Icons.business_center),
              label: 'Business',
            ),
            BottomNavigationBarItem(icon:_currentindex == 3?
            Icon(Icons.school):Icon(Icons.school_outlined),
              label: 'school',
            ),
            BottomNavigationBarItem(icon:_currentindex == 4?
            Icon(Icons.calculate):Icon(Icons.calculate_outlined),
              label: 'BMIcalculate',
            ),
          ],
          onTap: (index) { setState(() {
            _previousIndex = _currentindex;
            _currentindex=index;
            if (index == 0 ){
              if (_previousIndex == _currentindex) player.resume();
              player.play(AssetSource("z2.mp3"));
            };
            if (index == 1 ){
              if (_previousIndex == _currentindex) player.resume();
              player.play(AssetSource("z2.mp3"));
            };
            if (index == 2 ){
              if (_previousIndex == _currentindex) player.resume();
              player.play(AssetSource("z2.mp3"));
            };
            if (index == 3 ){
              if (_previousIndex == _currentindex) player.resume();
              player.play(AssetSource("z2.mp3"));
            };
          });
          },
        ),
      ),
    );
  }

}

class screen1 extends StatelessWidget {

  final String  s1='我出生在一個很平凡但很美滿的小家庭，父親是個公務員，'
      '在台電服務，母親是個家庭主婦，而弟弟和我都還在學校求學。'
      '父母用民主的方式管教我們，希望我們能夠獨立自主、主動學習，'
      '累積人生經驗，但他們會適時的給予鼓勵和建議，父母親只對'
      '我們要求兩件事，第一是保持健康，第二是著重課業。因為沒有'
      '健康的身體，就算有再多的才華、再大的抱負也無法發揮出來。'
      '又因為家境並不富裕，所以必須專心於課業上，學得一技之長'
      '，將來才能自立更生。除了課業之外，其他方面我也沒有偏廢。'
      '在高一時加入學校管樂隊，吹奏低音號，每天升旗參加出勤，在'
      '這裡不但使我對管樂器有進一步的認識，還認識了許多朋友，因此'
      '在那個時候，參加社團已成為我放學後的一大休閒。而我最喜歡的'
      '運動是棒球，我常在電視上或球場上觀賞職棒比賽，欣賞球員的美姿'
      '，模仿其動作。我常利用課餘時間約同學一起出外打球，記得'
      '在高二時，班上組隊參加班際壘球賽，那時我擔任隊長，防守二壘，'
      '首先展開攻勢，激起球隊士氣，最後終以一分之差贏得了最後勝利。'
      '除了棒球之外，我也很喜歡藍球、排球等，因此使得原本瘦弱的身體'
      '，變得強壯許多。';

  @override
  Widget build(BuildContext context) {

    player.play(AssetSource("z2.mp3"));

    return SingleChildScrollView(
      child: Column(
        children:<Widget>[
          //先放個標題
          Padding(padding: EdgeInsets.fromLTRB(10, 30, 10, 20),
            child: Text("關於我",
                style: TextStyle(fontSize:24,
                  fontWeight:FontWeight.bold,)),
          ),
          //文字自傳部份
          Container(
            padding: EdgeInsets.all(20),
            margin: EdgeInsets.fromLTRB(30, 0, 30, 50),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.black, width: 3),
              borderRadius: BorderRadius.circular(10), //邊界圓角
              boxShadow: [ BoxShadow(color: Colors.grey,
                  offset: Offset(6, 6)),
              ],),
            child:Text(s1,
              style: TextStyle(fontSize: 20,
                  color: Colors.white60,
                  fontWeight: FontWeight.bold),),
          ),

          //放一張照片
          Container(
            color: Colors.redAccent,
            child: Image.asset('images/D1.png'),
            height: 200,
            width: 200,
          ),
          SizedBox(height: 30,),

          //一列放兩個圖
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Container(
                width: 150,
                height: 150,
                decoration: BoxDecoration(
                  border: Border.all(
                    width: 2,
                    color: Colors.red,
                    style: BorderStyle.solid,
                  ),
                  borderRadius: BorderRadius.circular(30),
                  image: DecorationImage(
                    image: AssetImage('images/D1.png'),
                    fit: BoxFit.cover ,
                  ),
                  color: Colors.white,
                ),
              ),
              Container(
                width: 150,
                height: 150,
                decoration: BoxDecoration(
                  border: Border.all(
                    width: 2,
                    color: Colors.red,
                    style: BorderStyle.solid,
                  ),
                  borderRadius: BorderRadius.circular(30),
                  image: DecorationImage(
                    image: AssetImage('images/D1.png'),
                    fit: BoxFit.cover ,
                  ),
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class screen2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(child:Text('學習歷程'),);
  }
}

class screen3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child:Column(
        children: [
          //有多種排版方式, 此處以最直覺的方式將每一列放文字內容
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [Text("大一時期"),],
          ),
          SizedBox(height: 10,),
          Row(mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                height: 200,
                width: 200,
                child: ListView(
                  children: [
                    //條列式參考
                    Text('1. 學好英文'),
                    Text('2. 組合語言'),
                    Text('3. 考取證照'),
                    Text('4. 人際關係'),
                  ],
                ),
              ),
            ],),
          Row(),
          Row(),
          Row(),
          Row(),
          Row(),
          Row(),
        ],
      ),);
  }
}

class screen4 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(child:Text('專案方向'),);
  }
}

class screen5 extends StatelessWidget {

  String imageLink = 'images/D1.png';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget> [
              Container(
                width: 200,
                height: 200,
                decoration: BoxDecoration(
                  border: Border.all(
                      color: Colors.purple, width: 5, style: BorderStyle.solid),
                  borderRadius: BorderRadius.circular(30),
                  image: DecorationImage(image:AssetImage(imageLink),
                      fit:BoxFit.cover),
                  color: Colors.white,
                ),
              ),
              SizedBox(height:10),
              Text("我的BMI程式",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 30,
                  fontFamily: "kai",              //變更為楷書字體
                  color: Colors.amber,
                  fontWeight: FontWeight.bold,),
              ),
              SizedBox(height: 30,),
              ElevatedButton(onPressed: () {

                Navigator.push(context, MaterialPageRoute(builder: (context)=> MyBMI()));
              },
                child: Text("進入"),)
            ]

        ),
      ),
    );
  }
}

//之前的BMI計算機畫面
class MyBMI extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(theme: ThemeData(primaryColor: Colors.pinkAccent) ,home: demo(),);
  }
}

class demo extends StatefulWidget {
  @override
  demoState createState() => demoState();
}

class demoState extends State<demo> {

  TextEditingController heightController=TextEditingController();
  TextEditingController weightController=TextEditingController();
  double? result1;
  String? bmi_status;
  bool validateh=false, validatew=false;
  bool visible1=true;

  Color? getTextColor(String? s1) {
    if (s1=="正常~") {  return Colors.green;   }
    else if (s1=="過輕...") {  return Colors.amberAccent;   }
    else if (s1=="過重!") {  return Colors.redAccent;   }
  }

  @override
  void dispose() {
    heightController.dispose();
    weightController.dispose();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text("BMI計算機"),
      centerTitle: true,
      backgroundColor: Colors.greenAccent,),
      body:
      ListView(
        padding:EdgeInsets.only(top:50, left:10, right:10),
        children: <Widget> [
          Container(
              padding: EdgeInsets.symmetric(horizontal: 30.0),
              color:Colors.grey.shade300,
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    TextField(
                      controller: heightController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        labelText: '請輸入身高',
                        hintText: 'cm',
                        errorText: validateh? "不得為空":null,
                        icon: Icon(Icons.trending_up),
                      ),
                      style: TextStyle(fontSize: 22),
                    ),
                    SizedBox(height: 20),
                    TextField(
                      controller: weightController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        labelText: '請輸入體重',
                        hintText: 'Kg',
                        errorText: validatew? "不得為空":null,
                        icon: Icon(Icons.trending_down),
                      ),
                      style: TextStyle(fontSize: 22),
                    ),
                    SizedBox(height: 15),
                    ElevatedButton(
                      child: Text("計算", style: TextStyle(color: Colors.white),),
                      onPressed: () {
                        setState(() {
                          heightController.text.isEmpty? validateh=true:validateh=false;
                          weightController.text.isEmpty? validatew=true:validatew=false;
                          visible1=(validateh || validatew)? false:true;
                        });
                        calculateBMI(); },
                      style: ElevatedButton.styleFrom(textStyle: TextStyle(fontSize: 20)),
                    ),
                    SizedBox(height: 15),
                  ]
              )
          ),
          SizedBox(height: 15),

          Visibility(
            visible: visible1,
            child:
            Container(
              padding: EdgeInsets.symmetric(horizontal: 30.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    result1==null? "":"您的BMI值=${result1?.toStringAsFixed(2)}",
                    style: TextStyle(color:Colors.blueAccent,
                        fontSize: 22,
                        fontWeight: FontWeight.w500),
                  ),
                  SizedBox(height: 15),
                  RichText(text: TextSpan(style:TextStyle(color: Colors.blueAccent,
                      fontSize: 22,
                      fontWeight: FontWeight.w500),
                    children:<TextSpan>[
                      TextSpan(text: bmi_status==null? "":"您的體重狀態為："),
                      TextSpan(text: bmi_status==null? "":"$bmi_status",
                          style:TextStyle(color: getTextColor(bmi_status),
                              fontWeight: FontWeight.bold)),
                    ],),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
  void calculateBMI() {
    if (heightController.text!="" && weightController.text!="") {
      setState(() {
        double h=double.parse(heightController.text)/100;
        double w=double.parse(weightController.text);
        result1=w/(h*h);
        if (result1!<18.5) {
          bmi_status="過輕...";
        }
        else if (result1!>25) {
          bmi_status="過重!";
        }
        else { bmi_status="正常~"; }
      });
    }
    else {
      setState(() {
        result1=null;
        bmi_status=null;
      });
      showDialog(context: context, builder:(context) {
        return AlertDialog(title:Text("警告"),
          content:Text("身高體重不得為空!"),
          actions:<Widget>[
            TextButton(onPressed: ()=>Navigator.pop(context),
              child: Text("了解"),)
          ],);
      });
    }
  }
}