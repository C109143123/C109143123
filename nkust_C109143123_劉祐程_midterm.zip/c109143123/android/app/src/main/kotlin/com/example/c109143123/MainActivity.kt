package com.example.c109143123

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
