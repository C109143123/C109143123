import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'dart:async';


final player=AudioPlayer()..setReleaseMode(ReleaseMode.loop);//音樂循環

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  final tabs=[
    Center(child: screen1()),
    Center(child: screen2()),
    Center(child: screen3()),
    Center(child: screen4()),
  ];

  int _previousIndex = 0;
  int _currentindex = 0;

  @override
  Widget build(BuildContext context) {
    if (_currentindex == 0) player.play(AssetSource("z2.mp3"));
    return MaterialApp(
      home: Scaffold(
        body: tabs[_currentindex],
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.blue,
          selectedItemColor: Colors.white,
          selectedFontSize: 20.0,
          unselectedFontSize: 15.0,
          iconSize: 30.0,
          currentIndex: _currentindex,
          items: [
            BottomNavigationBarItem(icon:_currentindex == 0?
            Icon(Icons.home_outlined):Icon(Icons.home),
              label: 'Home',
            ),
            BottomNavigationBarItem(icon:_currentindex == 1?
            Icon(Icons.search): Icon(Icons.saved_search),
              label: 'search',
            ),
            BottomNavigationBarItem(icon:_currentindex == 2?
            Icon(Icons.person):Icon(Icons.person_add),
              label: 'Customer',
            ),
            BottomNavigationBarItem(icon:_currentindex == 4?
            Icon(Icons.favorite_border):Icon(Icons.favorite),
              label: 'MyFavorite',
            ),
          ],
          onTap: (index) { setState(() {
            _previousIndex = _currentindex;
            _currentindex=index;
            if (index == 0 ){
              if (_previousIndex == _currentindex) player.resume();
              player.play(AssetSource("z2.mp3"));
            };
            if (index == 1 ){
              if (_previousIndex == _currentindex) player.resume();
              player.play(AssetSource("z2.mp3"));
            };
            if (index == 2 ){
              if (_previousIndex == _currentindex) player.resume();
              player.play(AssetSource("z2.mp3"));
            };
            if (index == 3 ){
              if (_previousIndex == _currentindex) player.resume();
              player.play(AssetSource("z2.mp3"));
            };
          });
          },
        ),
      ),
    );
  }

}

class screen1 extends StatelessWidget {

  List<String> images = [
    "images/coffee.jpg",
    "images/AlcoholDrink.jpg",
    "images/Soup.jpg",
    "images/pizza.jpg"
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
        title: Text("Recipe"),
        backgroundColor: Colors.blue,
      ),
        body: Container(
            padding: EdgeInsets.all(12.0),
            child: GridView.builder(
              itemCount: images.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                //crossAxisSpacing: 10.0,
                //mainAxisSpacing: 1.0
              ),
              itemBuilder: (BuildContext context, int index){
                return GestureDetector(
                  child: Image.asset(images[index],),
                  onTap: () {
                    if (index==0)
                      Navigator.push(context, MaterialPageRoute(builder: (context) => Coffee()));
                    if (index==1)
                      Navigator.push(context, MaterialPageRoute(builder: (context) => AlcoholDrink()));
                    if (index==2)
                      Navigator.push(context, MaterialPageRoute(builder: (context) => Soup()));
                    if (index==3)
                      Navigator.push(context, MaterialPageRoute(builder: (context) => Pizza()));
                  },);
              },
            )),
      ),
    );
  }
}

class screen2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Search"),
          backgroundColor: Colors.blue,
        ),
        body: Center(
          child: ElevatedButton(
            child:  Text("搜尋"),
            onPressed: (){},
          ) ,
        ),
      ),
    );
  }
}

class screen3 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home:  Scaffold(
        appBar: AppBar(
          title: Text("Customer"),
          backgroundColor: Colors.blue,
        ),
        body: Center(
          child: Column(
               children: [
                 Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [Text("會員資料"),],
                    ),
              SizedBox(height: 10,),
              Row(mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                        height: 200,
                        width: 200,
                        child: ListView(
                              children: [
                                  //條列式參考
                                  Text('1. 姓名'),
                                  Text('2. 會員帳號'),
                                  Text('3. 會員密碼'),
                                  Text('4. 電話號碼'),
                                  ],
                   ),
                 ),
             ]
            ),
          ],
         ),
        ),
      ),
    );
  }
}

class screen4 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("MyFavorite"),
          backgroundColor: Colors.blue,
        ),
        body: Center(
          child: Text("收藏"),
        ),
      ),
    );
  }
}

//----------父類分割線-----------//

class Coffee extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Coffee'),
      ),
      body: Center(
        child: ElevatedButton(
          child: Text('泡沫咖啡'),
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => Cappuccino()));
            // Navigate to second route when tapped.
          },
        ),
      ),
    );
  }
}

class AlcoholDrink extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('AlcoholDrink'),
      ),
      body: Center(
        child: ElevatedButton(
          child: Text('雞尾酒'),
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => Cocktail()));
            // Navigate to second route when tapped.
          },
        ),
      ),
    );
  }
}

class Soup extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Soup'),
      ),
      body: Center(
        child: ElevatedButton(
          child: Text('玉米濃湯'),
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => CornSoup()));
            // Navigate to second route when tapped.
          },
        ),
      ),
    );
  }
}

class Pizza extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pizza'),
      ),
      body: Center(
        child: ElevatedButton(
          child: Text('培根披薩'),
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => BaconPizza()));
            // Navigate to second route when tapped.
          },
        ),
      ),
    );
  }
}

//----------子類分割線-----------//

class Cappuccino extends StatelessWidget {

  final String  s1 =
  '''  材料：速溶黑咖啡粉、細砂糖、水、餅乾、餅乾條、可可粉
  做法：黑咖啡粉、細砂糖、水按1:1:1的比例攪拌融化，再用打蛋器打發至奶油霜質地；杯裏放入冰塊，倒入牛奶，再把打好的泡沫咖啡倒在牛奶上面就可以啦～最後還可以撒些可可粉，用餅乾和餅乾棒裝飾一下。''';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Cappuccino"),
          backgroundColor: Colors.blue,
        ),
        body: Container(
          child : Column(
            children:<Widget>[
              Padding(padding: EdgeInsets.fromLTRB(10, 30, 10, 20),
                child: Text("泡沫咖啡",
                    style: TextStyle(fontSize:24,
                      fontWeight:FontWeight.bold,)),
              ),
              Container(
                padding: EdgeInsets.all(20),
                margin: EdgeInsets.fromLTRB(30, 0, 30, 50),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.white60 , width: 3),
                  borderRadius: BorderRadius.circular(10), //邊界圓角
                  boxShadow: [ BoxShadow(color: Colors.grey,
                      offset: Offset(6, 6)),
                  ],),
                child:Text(s1,
                  style: TextStyle(fontSize: 14,
                      color: Colors.white60,
                      fontWeight: FontWeight.bold),),
              ),
              Container(
                color: Colors.white,
                child: Image.asset('images/CoffeeSimple.jpg'),
                height: 200,
                width: 200,
              ),
              SizedBox(height: 30,),
            ],
          ),

        ),
      ),
    );
  }
}

class Cocktail extends StatelessWidget {

  final String  s1 =
  '''1.把青檸榨汁，與新鮮薄荷葉和砂糖放入杯中
2.將杯中材料稍微攪拌擠壓，盡量揉碎薄荷葉
3.加入蘭姆酒及碎冰
4.加入蘇打水攪拌一下
5.可把檸檬片裝飾在杯緣，及完成後上面再灑幾片帶點薄荷連根葉片當點綴''';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("AlcoholDrink"),
          backgroundColor: Colors.blue,
        ),
        body: Container(
          child : Column(
            children:<Widget>[
              //先放個標題
              Padding(padding: EdgeInsets.fromLTRB(10, 30, 10, 20),
                child: Text("雞尾酒",
                    style: TextStyle(fontSize:24,
                      fontWeight:FontWeight.bold,)),
              ),
              Container(
                padding: EdgeInsets.all(20),
                margin: EdgeInsets.fromLTRB(30, 0, 30, 50),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.white60 , width: 3),
                  borderRadius: BorderRadius.circular(10), //邊界圓角
                  boxShadow: [ BoxShadow(color: Colors.grey,
                      offset: Offset(6, 6)),
                  ],),
                child:Text(s1,
                  style: TextStyle(fontSize: 14,
                      color: Colors.white60,
                      fontWeight: FontWeight.bold),),
              ),
              Container(
                color: Colors.white,
                child: Image.asset('images/Cocktail.jpg'),
                height: 200,
                width: 200,
              ),
              SizedBox(height: 30,),
            ],
          ),

        ),
      ),
    );
  }
}

class CornSoup extends StatelessWidget {

  final String  s1 =
  '''1.洋蔥切末備用。
2.玉米洗淨後切成三段，將玉米粒沿著玉米梗的邊緣削下來。
3.準備約1公升的水，將玉米梗與一半的鴻禧菇加入，熬成高湯備用。
4.鍋熱放油，加入洋蔥末炒香，再把玉米粒、剩下的鴻禧菇下鍋稍微拌炒，起鍋備用。 ...
5.接著將奶油加熱融化，放入麵粉拌炒至起泡，鍋子離火。
6. 將煮好的高湯分四次倒入鍋中，邊倒邊攪拌至糊狀。
7. 將步驟4的材料加入湯裡，繼續以小火煮10分鐘，邊煮邊攪拌，避免鍋底燒焦。
8. 最後加入打散的蛋液，再以鹽巴、黑胡椒調味即可享用！''';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Soup"),
          backgroundColor: Colors.blue,
        ),
        body: Container(
          child : Column(
            children:<Widget>[
              //先放個標題
              Padding(padding: EdgeInsets.fromLTRB(10, 30, 10, 20),
                child: Text("玉米濃湯",
                    style: TextStyle(fontSize:24,
                      fontWeight:FontWeight.bold,)),
              ),
              Container(
                padding: EdgeInsets.all(20),
                margin: EdgeInsets.fromLTRB(30, 0, 30, 50),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.white60 , width: 3),
                  borderRadius: BorderRadius.circular(10), //邊界圓角
                  boxShadow: [ BoxShadow(color: Colors.grey,
                      offset: Offset(6, 6)),
                  ],),
                child:Text(s1,
                  style: TextStyle(fontSize: 14,
                      color: Colors.white60,
                      fontWeight: FontWeight.bold),),
              ),
              Container(
                color: Colors.white,
                child: Image.asset('images/CornSoup.jpg'),
                height: 230,
                width: 230,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class BaconPizza extends StatelessWidget {
  final String  s1 =
  '''1.將麵皮放入抹油的烤盤中，移入預熱210℃的烤箱中，烘烤約7分鐘，至顏色呈金黃色後取出。
2.將培根切片，洋蔥去皮切成圈，備用。
3.將烤盤刷上一層薄油，放入作法1餅皮，並抹上蕃茄披薩醬。
4.作法3上均勻撒上起司絲，再均勻舖上作法2材料，最後再撒上黑胡椒粉、俄力岡和適量起司絲。
5.將作法4移入預熱200℃的烤箱中，烘烤約6分鐘，至起司表面呈金黃色後，即可取出。''';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Pizza"),
          backgroundColor: Colors.blue,
        ),
        body: Container(
          child : Column(
            children:<Widget>[
              //先放個標題
              Padding(padding: EdgeInsets.fromLTRB(10, 30, 10, 20),
                child: Text("培根披薩",
                    style: TextStyle(fontSize:24,
                      fontWeight:FontWeight.bold,)),
              ),
              Container(
                padding: EdgeInsets.all(20),
                margin: EdgeInsets.fromLTRB(30, 0, 30, 50),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.white60 , width: 3),
                  borderRadius: BorderRadius.circular(10), //邊界圓角
                  boxShadow: [ BoxShadow(color: Colors.grey,
                      offset: Offset(6, 6)),
                  ],),
                child:Text(s1,
                  style: TextStyle(fontSize: 14,
                      color: Colors.white60,
                      fontWeight: FontWeight.bold),),
              ),
              Container(
                color: Colors.white,
                child: Image.asset('images/BaconPizza.jpg'),
                height: 230,
                width: 230,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

//----------分頁分割線-----------//

class P4 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child:Column(
        children: [
          //有多種排版方式, 此處以最直覺的方式將每一列放文字內容
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [Text("大一時期"),],
          ),
          SizedBox(height: 10,),
          Row(mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                height: 200,
                width: 200,
                child: ListView(
                  children: [
                    //條列式參考
                    Text('1. 學好英文'),
                    Text('2. 組合語言'),
                    Text('3. 考取證照'),
                    Text('4. 人際關係'),
                  ],
                ),
              ),
            ],),
          Row(),
          Row(),
          Row(),
          Row(),
          Row(),
          Row(),
        ],
      ),);
  }
}