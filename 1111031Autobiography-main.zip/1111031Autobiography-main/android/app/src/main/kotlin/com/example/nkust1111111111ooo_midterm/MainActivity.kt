package com.example.nkust1111111111ooo_midterm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
